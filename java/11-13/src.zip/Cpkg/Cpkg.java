package Cpkg;

public interface Cpkg {
    int c=10;
    void show();
}
