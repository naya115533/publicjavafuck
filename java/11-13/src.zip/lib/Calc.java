package lib;

public abstract class Calc {

        public abstract int add(int a,int b);
        public abstract int sub(int a,int b);
        public abstract int pro(int a,int b);
    }
