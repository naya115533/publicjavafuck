package lib;

public interface Coke {

    final double pi=3.14;
    void show();
}
